import 'package:flutter/material.dart';

void main() => runApp(const TikKingApp());

const red = Color(0xFFE5092A);
const blue = Color(0xFF4A8DFF);
const black = Color(0xFF090A0D);
const panel = Color(0xFF17191F);

class TikKingApp extends StatelessWidget {
  const TikKingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'TIK KING', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: black,
      colorScheme: const ColorScheme.dark(primary: red, secondary: blue, surface: panel), useMaterial3: true,
      appBarTheme: const AppBarTheme(backgroundColor: black, foregroundColor: Colors.white)),
    home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int selected = 0;
  final pages = const [HomePage(), VideosPage(), CreatePage(), MessagesPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: selected, children: pages),
    bottomNavigationBar: NavigationBar(backgroundColor: const Color(0xFF111217), indicatorColor: red.withOpacity(.2), selectedIndex: selected,
      onDestinationSelected: (i) {
        if (i == 2) { Navigator.push(context, MaterialPageRoute(builder: (_) => const CreatePage(fullPage: true))); }
        else { setState(() => selected = i); }
      },
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Videos'),
        NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Create'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Messages'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ]),
  );
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  final liked = <int>{};
  final posts = const [
    ('sami.creator', 'New day, new goals. Keep moving. 🔥', 'S'),
    ('hana.daily', 'Little moments, big memories 💙', 'H'),
    ('abebe.vibes', 'Who is ready for the weekend?', 'A'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('TIK KING', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)), actions: [
      IconButton(onPressed: () => showInfo(context, 'Explore', 'Search users, hashtags, photos and videos will be connected later.'), icon: const Icon(Icons.search)),
      IconButton(onPressed: () => showInfo(context, 'Notifications', 'Notifications will work when accounts and the backend are connected.'), icon: const Icon(Icons.notifications_none)),
    ]),
    body: ListView(children: [
      SizedBox(height: 110, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(8), children: const [
        StoryBubble(label: 'Your story', initial: '+', isAdd: true), StoryBubble(label: 'sami.creator', initial: 'S'),
        StoryBubble(label: 'hana.daily', initial: 'H'), StoryBubble(label: 'abebe.vibes', initial: 'A'),
        StoryBubble(label: 'mimi_22', initial: 'M'), StoryBubble(label: 'dani.fit', initial: 'D'),
      ])),
      const Divider(color: Colors.white12),
      for (var i = 0; i < posts.length; i++) PostCard(user: posts[i].$1, caption: posts[i].$2, initial: posts[i].$3,
        isLiked: liked.contains(i), onLike: () => setState(() => liked.contains(i) ? liked.remove(i) : liked.add(i))),
    ]),
  );
}

class StoryBubble extends StatelessWidget {
  final String label, initial; final bool isAdd;
  const StoryBubble({super.key, required this.label, required this.initial, this.isAdd = false});
  @override Widget build(BuildContext context) => SizedBox(width: 78, child: Column(children: [
    Container(padding: const EdgeInsets.all(3), decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: isAdd ? [blue, blue] : [red, blue])),
      child: CircleAvatar(radius: 27, backgroundColor: panel, child: isAdd ? const Icon(Icons.add) : Text(initial, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)))),
    const SizedBox(height: 5), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
  ]));
}

class PostCard extends StatelessWidget {
  final String user, caption, initial; final bool isLiked; final VoidCallback onLike;
  const PostCard({super.key, required this.user, required this.caption, required this.initial, required this.isLiked, required this.onLike});
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    ListTile(leading: CircleAvatar(backgroundColor: red, child: Text(initial, style: const TextStyle(fontWeight: FontWeight.bold))),
      title: Text(user, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text('Suggested for you', style: TextStyle(fontSize: 11, color: Colors.white54)),
      trailing: IconButton(onPressed: () => showInfo(context, 'Post options', 'More options will be added later.'), icon: const Icon(Icons.more_horiz))),
    Container(height: 260, margin: const EdgeInsets.symmetric(horizontal: 10), width: double.infinity,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF252B3A), Color(0xFF551329), Color(0xFF102D4D)])),
      child: const Stack(children: [Center(child: Icon(Icons.image_outlined, size: 76, color: Colors.white24)), Positioned(left: 14, bottom: 14, child: Text('TIK KING • DEMO POST', style: TextStyle(fontSize: 10, letterSpacing: 1.1))) ])),
    Row(children: [
      IconButton(onPressed: onLike, icon: Icon(isLiked ? Icons.favorite : Icons.favorite_border, color: isLiked ? red : Colors.white)),
      IconButton(onPressed: () => showInfo(context, 'Comments', 'Comments need a connected database.'), icon: const Icon(Icons.mode_comment_outlined)),
      IconButton(onPressed: () => showInfo(context, 'Share', 'Sharing will be added later.'), icon: const Icon(Icons.send_outlined)), const Spacer(),
      IconButton(onPressed: () => showInfo(context, 'Saved posts', 'Saving posts requires a user account.'), icon: const Icon(Icons.bookmark_border)),
    ]),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(isLiked ? 'You and others like this' : 'Be the first to like this', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12))),
    Padding(padding: const EdgeInsets.fromLTRB(16, 5, 16, 15), child: RichText(text: TextSpan(style: const TextStyle(color: Colors.white, fontSize: 13), children: [TextSpan(text: '$user  ', style: const TextStyle(fontWeight: FontWeight.bold)), TextSpan(text: caption)]))),
    const Divider(color: Colors.white10),
  ]);
}

class VideosPage extends StatefulWidget { const VideosPage({super.key}); @override State<VideosPage> createState() => _VideosPageState(); }
class _VideosPageState extends State<VideosPage> {
  int index = 0; final names = const ['sami.creator', 'hana.daily', 'abebe.vibes'];
  void next() => setState(() => index = (index + 1) % names.length);
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('KING VIDEOS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2))),
    body: GestureDetector(onVerticalDragEnd: (_) => next(), child: Container(margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: index.isEven ? [const Color(0xFF3D1425), const Color(0xFF111A2B), black] : [const Color(0xFF102C45), const Color(0xFF27142C), black])),
      child: Stack(children: [
        const Center(child: Icon(Icons.play_circle_fill, size: 86, color: Colors.white70)),
        const Positioned(top: 18, left: 18, child: Text('DEMO VIDEO • SWIPE UP', style: TextStyle(fontSize: 10, letterSpacing: 1))),
        Positioned(left: 18, right: 75, bottom: 26, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('@${names[index]}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 7), const Text('Short videos, trends and moments. Real video playback requires video hosting.'), const SizedBox(height: 10), const Text('#TIKKING #ForYou', style: TextStyle(color: Colors.white70))])),
        Positioned(right: 10, bottom: 35, child: Column(children: [
          IconButton(onPressed: () => showInfo(context, 'Like video', 'Video likes will be saved after backend setup.'), icon: const Icon(Icons.favorite_border, size: 30)), const Text('Like', style: TextStyle(fontSize: 10)),
          const SizedBox(height: 12), IconButton(onPressed: () => showInfo(context, 'Comments', 'Video comments will be added later.'), icon: const Icon(Icons.comment_outlined, size: 28)), const Text('Comment', style: TextStyle(fontSize: 10)),
          const SizedBox(height: 12), IconButton(onPressed: next, icon: const Icon(Icons.skip_next, size: 30)), const Text('Next', style: TextStyle(fontSize: 10)),
        ])),
      ]))),
  );
}

class CreatePage extends StatelessWidget {
  final bool fullPage; const CreatePage({super.key, this.fullPage = false});
  @override Widget build(BuildContext context) => Scaffold(appBar: fullPage ? AppBar(title: const Text('Create')) : null,
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 20), const Text('Create something', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8), const Text('Choose what you want to share with the TIK KING community.', style: TextStyle(color: Colors.white60)), const SizedBox(height: 24),
      CreateTile(icon: Icons.photo_library_outlined, title: 'Photo or post', subtitle: 'Share a photo and caption', onTap: () => showInfo(context, 'Photo upload', 'Gallery picker and cloud upload are not connected yet.')),
      CreateTile(icon: Icons.video_collection_outlined, title: 'Short video', subtitle: 'Create a vertical video post', onTap: () => showInfo(context, 'Video upload', 'Video picker and hosting are not connected yet.')),
      CreateTile(icon: Icons.bolt, title: 'Story', subtitle: 'A post that expires after 24 hours', onTap: () => showInfo(context, 'Story', 'Story expiration needs backend support.')),
      CreateTile(icon: Icons.edit_note, title: 'Text note', subtitle: 'Share a quick thought', onTap: () => writeNote(context)),
      const Spacer(), const Text('Demo UI: uploads are not sent to a server yet.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)), const SizedBox(height: 12),
    ]))));
}
class CreateTile extends StatelessWidget {
  final IconData icon; final String title, subtitle; final VoidCallback onTap;
  const CreateTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override Widget build(BuildContext context) => Card(color: panel, margin: const EdgeInsets.only(bottom: 12), child: ListTile(onTap: onTap, contentPadding: const EdgeInsets.all(12),
    leading: Container(width: 48, height: 48, decoration: BoxDecoration(color: red.withOpacity(.18), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: red)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right)));
}
void writeNote(BuildContext context) {
  final controller = TextEditingController();
  showDialog(context: context, builder: (ctx) => AlertDialog(backgroundColor: panel, title: const Text('Write a note'),
    content: TextField(controller: controller, maxLength: 160, maxLines: 3, decoration: const InputDecoration(hintText: 'What is on your mind?')),
    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () { final text = controller.text.trim(); Navigator.pop(ctx); showInfo(context, 'Note preview', text.isEmpty ? 'No text entered.' : text); }, child: const Text('Preview'))]));
}

class MessagesPage extends StatelessWidget { const MessagesPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Messages', style: TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () => showInfo(context, 'New message', 'User search and private messaging need backend integration.'), icon: const Icon(Icons.edit_square))]),
    body: ListView(children: const [Padding(padding: EdgeInsets.all(16), child: Text('Your conversations', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
      ChatTile(initial: 'H', name: 'hana.daily', message: 'Hey! How are you?'), ChatTile(initial: 'S', name: 'sami.creator', message: 'Check out my new video 🔥'), ChatTile(initial: 'A', name: 'abebe.vibes', message: 'Thanks for the follow!'),
      Padding(padding: EdgeInsets.all(18), child: Text('Sample conversations only — not real messages.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12))) ]));
  }
class ChatTile extends StatelessWidget { final String initial, name, message; const ChatTile({super.key, required this.initial, required this.name, required this.message});
  @override Widget build(BuildContext context) => ListTile(onTap: () => showInfo(context, 'Chat with $name', 'Real-time messaging will be added with the backend.'), leading: CircleAvatar(backgroundColor: blue, child: Text(initial)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(message), trailing: const Text('Demo', style: TextStyle(color: Colors.white38, fontSize: 11))); }

class ProfilePage extends StatelessWidget { const ProfilePage({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Profile', style: TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () => showInfo(context, 'Settings', 'Account settings and privacy controls will be added.'), icon: const Icon(Icons.settings_outlined))]),
    body: ListView(padding: const EdgeInsets.all(18), children: [const SizedBox(height: 10), const Center(child: CircleAvatar(radius: 48, backgroundColor: red, child: Text('TK', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)))),
      const SizedBox(height: 12), const Center(child: Text('TIK KING USER', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))), const Center(child: Text('@your_username • Demo profile', style: TextStyle(color: Colors.white54))), const SizedBox(height: 22),
      const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [Stat(value: '0', label: 'Posts'), Stat(value: '0', label: 'Followers'), Stat(value: '0', label: 'Following')]), const SizedBox(height: 22),
      FilledButton(onPressed: () => showInfo(context, 'Edit profile', 'Profile editing will be enabled with account storage.'), child: const Text('Edit profile')), const SizedBox(height: 12),
      ProfileTile(icon: Icons.insights_outlined, title: 'Creator dashboard', subtitle: 'Views, reach and earnings', onTap: () => showInfo(context, 'Creator dashboard', 'Analytics need real account and video data.')),
      ProfileTile(icon: Icons.verified_outlined, title: 'Get verified', subtitle: 'Verification options', onTap: () => showInfo(context, 'Verification', 'Payments and review need secure integration.')),
      ProfileTile(icon: Icons.monetization_on_outlined, title: 'Coins and gifts', subtitle: 'Wallet and creator earnings', onTap: () => showInfo(context, 'Coins and gifts', 'A secure wallet and payment integration are required.')),
      ProfileTile(icon: Icons.campaign_outlined, title: 'Promote content', subtitle: 'Clearly labeled paid promotion', onTap: () => showInfo(context, 'Promotion', 'Paid promotion must be labeled and must not use fake engagement.')),
      ProfileTile(icon: Icons.lock_outline, title: 'Privacy and security', subtitle: 'Login, recovery and account controls', onTap: () => showInfo(context, 'Privacy and security', 'Authentication and account recovery are not connected yet.')),
    ]));
  }
class Stat extends StatelessWidget { final String value, label; const Stat({super.key, required this.value, required this.label}); @override Widget build(BuildContext context) => Column(children: [Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white54))]); }
class ProfileTile extends StatelessWidget { final IconData icon; final String title, subtitle; final VoidCallback onTap; const ProfileTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override Widget build(BuildContext context) => Card(color: panel, child: ListTile(onTap: onTap, leading: Icon(icon, color: blue), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right))); }

void showInfo(BuildContext context, String title, String message) => showDialog<void>(context: context, builder: (ctx) => AlertDialog(backgroundColor: panel, title: Text(title), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))]));
