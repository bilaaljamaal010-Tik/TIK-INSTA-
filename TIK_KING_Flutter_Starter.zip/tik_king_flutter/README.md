# TIK KING — Flutter starter project

A Flutter UI starter for an Instagram + TikTok-inspired social app. Theme: black and red with white and blue accents.

## Included
- Home feed with sample post cards and story bubbles
- Local demo like toggles
- Separate vertical-video-style screen with swipe-to-next demo behavior
- Create entry points for photo posts, videos, stories and text notes
- Sample messages list
- Profile screen with creator dashboard, verification, coins/gifts, promotion and privacy entry points
- Five-tab navigation and dark theme

## Important status
This is a **UI starter**, not a production social network. Sample content is local demo content; no real account or media data is uploaded. Real sign-in/account recovery, database, real-time chat, followers/comments/notifications, gallery upload, video hosting, 24-hour story expiry, payments, coin wallet, gifts and creator payouts are not connected yet. Do not accept real payments or collect sensitive data until those parts are implemented, secured and tested.

## Build into an Android APK
On a computer with Flutter and the Android SDK installed:
1. Extract this ZIP.
2. Run `flutter pub get`.
3. Run `flutter run` to test.
4. Run `flutter build apk --release` to build an APK.
5. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Next integration plan
1. Configure Firebase Authentication (email/password first; Google and phone can follow).
2. Add Firestore or another database with strict security rules.
3. Choose media hosting after checking current regional availability, storage and bandwidth pricing.
4. Add upload/playback, moderation, reports, blocking and story expiration.
5. Add compliant payment handling for digital items and creator payouts.
6. Test on real Android devices before publishing.
